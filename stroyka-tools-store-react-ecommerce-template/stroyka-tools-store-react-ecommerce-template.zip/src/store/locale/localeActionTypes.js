// eslint-disable-next-line import/prefer-default-export
export const LOCALE_CHANGE = 'LOCALE_CHANGE';
