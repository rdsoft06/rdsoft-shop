import compareReducer from './compareReducer';

export * from './compareActions';
export default compareReducer;
