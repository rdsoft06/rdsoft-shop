import wishlistReducer from './wishlistReducer';

export * from './wishlistActions';
export default wishlistReducer;
